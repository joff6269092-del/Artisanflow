package com.artisanflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Lead(
    val name: String,
    val project: String,
    val budget: String,
    val status: String,
    val message: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArtisanFlowApp() }
    }
}

@Composable
fun ArtisanFlowApp() {
    var screen by remember { mutableStateOf("home") }
    var leads by remember {
        mutableStateOf(
            listOf(
                Lead("Jean Dupont", "Fuite sous évier", "300 €", "À traiter",
                    "Bonjour, j'ai une fuite sous mon évier depuis ce matin. Pouvez-vous intervenir rapidement ?"),
                Lead("Sophie Martin", "Rénovation salle de bain", "8 000–12 000 €", "Qualifié",
                    "Bonjour, je souhaite refaire entièrement ma salle de bain. Je peux envoyer des photos.")
            )
        )
    }

    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavItem("home", Icons.Default.Home, "Accueil", screen) { screen = it }
                    NavItem("leads", Icons.Default.Mail, "Demandes", screen) { screen = it }
                    NavItem("clients", Icons.Default.Person, "Clients", screen) { screen = it }
                    NavItem("quotes", Icons.Default.Description, "Devis", screen) { screen = it }
                    NavItem("more", Icons.Default.MoreHoriz, "Plus", screen) { screen = it }
                }
            }
        ) { padding ->
            when (screen) {
                "home" -> HomeScreen(padding, leads, onTest = {
                    leads = listOf(
                        Lead("Thomas Leroy", "Rénovation cuisine", "6 000–9 000 €", "Nouveau",
                            "Bonjour, je voudrais refaire ma cuisine. Pouvez-vous venir voir le chantier ?")
                    ) + leads
                    screen = "leads"
                })
                "leads" -> LeadsScreen(padding, leads)
                "clients" -> SimpleScreen(padding, "Clients", "👤", "Vos clients apparaîtront ici.")
                "quotes" -> SimpleScreen(padding, "Devis", "📝", "Les devis créés apparaîtront ici.")
                else -> SimpleScreen(padding, "Plus", "⚙️", "Paramètres, abonnement et intégrations seront ajoutés dans les prochaines versions.")
            }
        }
    }
}

@Composable
fun NavItem(route: String, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String,
            current: String, onClick: (String) -> Unit) {
    NavigationBarItem(
        selected = current == route,
        onClick = { onClick(route) },
        icon = { Icon(icon, null) },
        label = { Text(label) }
    )
}

@Composable
fun HomeScreen(
    padding: PaddingValues,
    leads: List<Lead>,
    onTest: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(padding).background(Color(0xFFF8FAFC))
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Text("Bonjour 👋", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Voici ce qui mérite votre attention.", color = Color.Gray)
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = onTest,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(8.dp))
            Text("Simuler une demande client")
        }

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Demandes", leads.size.toString(), Modifier.weight(1f))
            StatCard("À traiter", leads.count { it.status == "À traiter" || it.status == "Nouveau" }.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Devis", "3", Modifier.weight(1f))
            StatCard("Relances", "5", Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
        Text("Dernières demandes", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Spacer(Modifier.height(10.dp))
        leads.take(3).forEach { LeadCard(it) }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.Gray, fontSize = 13.sp)
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun LeadsScreen(padding: PaddingValues, leads: List<Lead>) {
    Column(Modifier.fillMaxSize().padding(padding).background(Color(0xFFF8FAFC)).padding(20.dp)) {
        Text("Demandes clients", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Qualification et suivi", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(leads) { LeadCard(it, expanded = true) }
        }
    }
}

@Composable
fun LeadCard(lead: Lead, expanded: Boolean = false) {
    var show by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().clickable { show = !show },
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(lead.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(lead.project, color = Color.Gray)
                }
                AssistChip(onClick = {}, label = { Text(lead.status) })
            }
            Spacer(Modifier.height(8.dp))
            Text("Budget : ${lead.budget}", fontWeight = FontWeight.SemiBold)
            if (expanded || show) {
                Spacer(Modifier.height(10.dp))
                Text(lead.message, color = Color.DarkGray)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {}) { Text("Répondre") }
                    Button(onClick = {}) { Text("Qualifier avec IA") }
                }
            }
        }
    }
}

@Composable
fun SimpleScreen(padding: PaddingValues, title: String, emoji: String, text: String) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text(text, color = Color.Gray)
    }
}
