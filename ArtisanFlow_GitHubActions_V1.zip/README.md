# ArtisanFlow

V1 Android native app for artisans.

## Build on GitHub
The repository includes a GitHub Actions workflow:
- Go to **Actions**
- Select **Build ArtisanFlow APK**
- Press **Run workflow**
- When finished, open the workflow run and download the **ArtisanFlow-debug-apk** artifact.

The APK is a debug build intended for testing.
